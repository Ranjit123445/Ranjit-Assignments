package BankApplication_Services_Model;

public class Account {
	private long accountNo;
	private String user_name;
	private String user_Adress;
	private String pan_No;
	private int balance;

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accno) {
		this.accountNo = accno;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getUser_Adress() {
		return user_Adress;
	}

	public void setUser_Adress(String user_Adress) {
		this.user_Adress = user_Adress;
	}

	public String getPan_No() {
		return pan_No;
	}

	public void setPan_No(String pan_No) {
		this.pan_No = pan_No;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}
}
