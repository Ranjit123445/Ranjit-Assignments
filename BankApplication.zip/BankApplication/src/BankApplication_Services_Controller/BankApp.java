package BankApplication_Services_Controller;

import java.util.Scanner;

import BankApplication_Services.BankService;
import BankApplication_Services.BankserviceIMPL;

public class BankApp {
	
public static void main(String[] args) {
	BankService bankServices=new BankserviceIMPL();
	boolean flag=true;
	while(flag) {
	System.out.println("press 1 For account creation");
	System.out.println(" press 2 for view account ");
	System.out.println(" press 3 for withdraw money");
	System.out.println(" press 4 for deposit money");
	System.out.println(" press 5 for update detail");
	System.out.println(" press 6 for EXIT");
	Scanner sc=new Scanner(System.in);
	int ch = sc.nextInt();
	switch (ch) {
	case 1:
		bankServices.creatAccount();
		break;
	case 2:
		bankServices.ViewAccountDetails();
		break;
	case 3:
		bankServices.WithdrawMoney();
		break;
	case 4:
		bankServices.DepositMoney();
		break;
	case 5:
		bankServices.UpdateAccountDetails();
		break;
	case 6:
		flag=false;
		default:
			System.out.println("Invalid choice...!");
		
			
	}
	
	
}
}
}
