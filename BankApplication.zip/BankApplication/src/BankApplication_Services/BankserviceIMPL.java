package BankApplication_Services;

import java.util.Random;
import java.util.Scanner;

import BankApplication_Services_Model.Account;

public class BankserviceIMPL implements BankService {
	//private static final int Deposit = 40000;
	Account ac=new Account();
	Scanner sc=new Scanner(System.in);

	@Override
	public void creatAccount() {
		System.out.println(" Enter Account Name");
		String name= sc.next();
		ac.setUser_name(name);
		System.out.println(" Enter your Adress");
		String adress=sc.next();
		ac.setUser_Adress(adress);
		System.out.println("Enter your pan no ");
		String pan_NO=sc.next();
		ac.setPan_No(pan_NO);
		// Minimum user should Amount it should be 1000
		// if user enters less than minimum amount the tell him minimum condition to create the bank 
		//account is amt>=1000
		// user should not be able to withdraw money less than 500 rs 
		// users allos to withdraw multiple of 100's only.
		System.out.println( "Enter amount Deposit");
		int Deposit=sc.nextInt();
		ac.setBalance(Deposit);
		// generating Random number using random class
		Random random=new Random();
		int accno = random.nextInt();
		ac.setAccountNo(accno);
		System.out.println(" Your Account is created successfully and  your account no is "+accno);

	}

	@Override
	public void ViewAccountDetails() {
		System.out.println(" Enter your account Number");
		int userAccno=sc.nextInt();
		if (ac.getAccountNo()==userAccno) {
			System.out.println(" Fetching the Account details ");
			System.out.println(ac.getAccountNo());
			System.out.println(ac.getUser_name());
			System.out.println(ac.getUser_Adress());
			System.out.println(ac.getPan_No());
			System.out.println(ac.getBalance());
		}
		else {
			System.out.println(" create account first");
		}
	}

	@Override
	public void WithdrawMoney() {
		// enter his account number 
		System.out.println(" Enter your account number");
		int accnob=sc.nextInt();
		// accept that account number
		// if account number is same as account number present in the object
		// {
		if (ac.getAccountNo()== accnob) {
			// ask user to enter amount which he wants to withdraw
			System.out.println(" Enter the amount to withdraw");
			// accept that amount
			int DebitAmt=sc.nextInt();
			//Compare the entered amount with vailable amount in account 
			// then money only if amt< balance
			int balance = ac.getBalance();// code optimization
			if (DebitAmt < balance ) {
				balance =balance-DebitAmt;
			}
			//if amt > balance user know the balance is in sufficien
			else {
				System.out.println("insufficient balance ");
			}
			//balance -amt
			// let user know the Amount  withdrawal is successful
			//}
		}
		// other wise display msg saying create your account

		else {
			System.out.println(" Create your account first");
		}

	}

	@Override
	public void DepositMoney() {
		// enter accout number and varify it 
		System.out.println(" Enter your account number");
		int accnub=sc.nextInt();
		if(ac.getAccountNo()==accnub){
			System.out.println("Account number is varified");
		}
		else {
			System.out.println(" Create your account first");
		}
		// ask user to enter amount to diposit
		System.out.println(" Enter amount to Add");

		int EnterAmt=sc.nextInt();
		// add that amount to balance
		int balance = ac.getBalance();
		int totalBalance=EnterAmt+balance;
		ac.setBalance(totalBalance);
		System.out.println(	"Total amount:" +totalBalance);
		// print msg saying amount deposited succcessfuly and the available balance 
		System.out.println("amount Deposited successfully");


	}

	@Override
	public void UpdateAccountDetails() {
		// enter accout number and varify it 
		System.out.println(" Enter your account number");
		int accnub1=sc.nextInt();
		if(ac.getAccountNo()==accnub1){
			boolean flag =true;
			while(flag) {


				System.out.println("Press 1 for name update");
				System.out.println("Press 2 for adress update");
				System.out.println("Press 3 for pan update");
				System.out.println("Press 4 for  Exit");
				int ch=sc.nextInt();
				switch(ch) {
				case 1:
					System.out.println(" enter the name which you want update");
					String user_name =sc.next();
					ac.setUser_name(user_name);
					break;
				case 2:
					System.out.println(" Enter adress which you want update");
					String user_adress=sc.next();
					ac.setUser_Adress(user_adress);
					break;
				case 3:
					System.out.println(" Enetr pan number which you want to updatee");
					String user_pan=sc.next();
					ac.setPan_No(user_pan);
					System.out.println(" Pan number updated successfully");
					break;
				case 4:
					flag=false;
					break;

				default:
					System.out.println("Invalid choice....!");
				}
			}
		}
		else {
			System.out.println(" Create your account first");
		}
		// ask user to enter what you want update and press 1 for name and 2 for adress
		// and 3 for pan
		// set the values to the account obj acording to the selection
		// in the last print update details - call the get

	}

	@Override
	public void checkAccountBalance() {


	}

}
