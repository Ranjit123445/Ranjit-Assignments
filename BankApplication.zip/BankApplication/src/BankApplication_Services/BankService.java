package BankApplication_Services;
// by default here is abstract method 
public interface BankService {
public void creatAccount();
public void ViewAccountDetails();
public void WithdrawMoney();
public void DepositMoney();
public void UpdateAccountDetails();
public void checkAccountBalance();
}
// Assignmnets( Improvemnets in Project)
// Apply validation on pan number as first five charactors should be any upper case alphabet
// Then next four charactofrs should be any number from 0 to 9 .
// The last (tenth ) charctor should be any upper case alphabet
// also it should be 10 digit long
//Minimum user should Amount it should be 1000
// Check Account Balance
